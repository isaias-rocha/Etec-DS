package com.Matheus.ModularPAMlSharedePreferences;

import android.content.Context;
import android.content.SharedPreferences;


public class AnotacaoPreferencias{
    public final SharedPreferences preferences;
    public   final SharedPreferences.Editor editor;

    private static final  String CHAVE_NOME = "anotação";

    public AnotacaoPreferencias(Context context){
        preferences = context.getSharedPreferences("arqPreferencias", Context.MODE_PRIVATE);
        editor = preferences.edit();
    }
    public void salvarAnotacao(String anotacao)     {
        editor.putString(CHAVE_NOME, anotacao);
        editor.commit();
    }
    public String recuperarAnotacao ()  {
        return preferences.getString(CHAVE_NOME,"");
    }
}
